DROP DATABASE IF EXISTS F1_comprovacio;
CREATE DATABASE F1_comprovacio;
USE F1_comprovacio;
DELIMITER $$
DROP PROCEDURE IF EXISTS comprovacio_imp;
CREATE PROCEDURE comprovacio_imp()
BEGIN

  DECLARE r1, r2, v1, v2, c1, c2, t1, t2, s1, s2 INT;

  DROP TABLE IF EXISTS comprovaCount;
  CREATE TABLE comprovaCount(

    raceOLTP INT,
    raceOLAP INT,
    voltaOLTP INT,
    voltaOLAP INT,
    resultatsOLTP INT,
    resultatsOLAP INT,
    teamsOLTP INT,
    teamsOLAP INT,
    statusOLTP INT,
    statusOLAP INT,
    currentDate DATE,
    currentTime TIME,
    ok VARCHAR(255)

  );

  SELECT COUNT(*) FROM f1oltp.races AS r INTO r1;

  INSERT INTO comprovaCOUNT(raceOLTP)
  VALUES(r1);

  SELECT COUNT(*) FROM f1olap.raceOLAP INTO r2;

  UPDATE comprovaCount SET raceOLAP = (r2) WHERE 1 = 1;

  SELECT COUNT(*) FROM f1oltp.laptimes INTO v1;

  UPDATE comprovaCount SET voltaOLTP = (v1) WHERE 1 = 1;

  SELECT COUNT(*) FROM f1olap.resultatsvolta INTO v2;

  UPDATE comprovaCount SET voltaOLAP = (v2) WHERE 1 = 1;

  SELECT COUNT(DISTINCT d.driverStandingsId) FROM f1oltp.driverstandings AS d INTO c1;

  SELECT c1 + COUNT(*) FROM f1oltp.results AS r LEFT JOIN f1oltp.driverstandings AS d ON (r.raceId = d.raceId AND r.driverId = d.driverId) WHERE d.driverStandingsId IS NULL INTO c1;

  UPDATE comprovaCount SET resultatsOLTP = (c1) WHERE 1 = 1;

  SELECT COUNT(*) FROM f1olap.resultatscarrera INTO c2;

  UPDATE comprovaCount SET resultatsOLAP = (c2) WHERE 1 = 1;

  SELECT COUNT(DISTINCT c.constructorId, d.driverId) FROM f1oltp.constructors AS c JOIN f1oltp.results AS r ON c.constructorId = r.constructorId JOIN f1oltp.drivers AS d ON r.driverId = d.driverId INTO t1;

  UPDATE comprovaCount SET teamsOLTP = (t1) WHERE 1 = 1;

  SELECT COUNT(*) FROM f1olap.teams INTO t2;

  UPDATE comprovaCount SET teamsOLAP = (t2) WHERE 1 = 1;

  SELECT COUNT(*) FROM f1oltp.status INTO s1;

  UPDATE comprovaCount SET statusOLTP = (s1) WHERE 1 = 1;

  SELECT COUNT(*) FROM f1olap.statusOLAP INTO s2;

  UPDATE comprovaCount SET statusOLAP = (s2) WHERE 1 = 1;

  UPDATE comprovaCount SET currentDate = CURRENT_DATE() WHERE 1 = 1;

  UPDATE comprovaCount SET currentTime = CURRENT_TIME() WHERE 1 = 1;

  IF (r1 = r2 AND v1 = v2 AND c1 = c2 AND t1 = t2 AND s1 = s2) THEN

    UPDATE comprovaCount SET ok = 'OK' WHERE 1 = 1;

  ELSE

    UPDATE comprovaCount SET ok = 'Error' WHERE 1 = 1;

  end if;

  SELECT ok FROM comprovaCount;



END $$

DELIMITER ;
