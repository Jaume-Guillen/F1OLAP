USE F1OLTP;

SELECT c.name
FROM circuits AS c
WHERE c.country = 'Spain';

USE F1OLTP;

SELECT COUNT(p.stop) AS parades, q.driverId, r1.name
FROM laptimes AS l JOIN pitstops AS p ON (l.raceId = p.raceId AND l.driverId = p.driverId AND l.lap = p.lap) JOIN qualifying AS q ON (q.raceId = p.raceId AND q.driverId = p.driverId) JOIN results AS r ON(q.raceId = r.raceId AND q.driverId = r.driverId) JOIN races AS r1 ON r1.raceId = r.raceId JOIN circuits AS c ON r1.circuitId = c.circuitId
WHERE c.country = 'Australia' AND stop IS NOT NULL
GROUP BY l.raceId, l.driverId
HAVING AVG(l.position) > 5 AND parades > 0
ORDER BY q.driverId, r1.raceId;

USE F1OLTP;

INSERT INTO laptimes(raceId, driverId, lap, position, time, miliseconds) VALUES(20000, 2000, 1, 2, '11:00:00', 29);
UPDATE laptimes SET miliseconds = 0 WHERE raceId = 20004 AND driverId = 2000 AND lap =1;
DELETE FROM laptimes WHERE raceId = 20000 AND driverId = 2000 AND lap =1;

USE F1OLAP;

SELECT DISTINCT c.nameCircuit
FROM raceolap AS c
WHERE c.country = 'Spain';

USE F1OLAP;

SELECT COUNT(v.stop) AS parades, v.driverId, r.nameRace
FROM resultatsvolta AS v JOIN raceolap AS r ON r.raceId = v.raceId
WHERE stop IS NOT NULL AND r.country = 'Australia' AND NOT stop = -1
GROUP BY v.raceId, v.driverId
HAVING AVG(v.position) > 5 AND parades > 0
ORDER BY v.driverId, r.raceId;

USE F1OLAP;

INSERT INTO resultatsvolta(raceId, driverId, lap, position, timeLap, milisecondsLap, stop) VALUES(20000, 2000, 1, 2, '11:00:00', 29, -2);
UPDATE resultatsvolta SET milisecondsLap = 0 WHERE raceId = 20000 AND driverId = 2000;
DELETE FROM resultatsvolta WHERE raceId = 20000 AND driverId = 2000 AND lap =1;