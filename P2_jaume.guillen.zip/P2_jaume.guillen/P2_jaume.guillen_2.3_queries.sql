USE F1OLAP;

SELECT s.statusId, s.status
FROM statusOLAP AS s LEFT OUTER JOIN resultatscarrera AS p ON p.statusId = s.statusId
WHERE p.statusId IS NULL;

DROP TABLE IF EXISTS auxTable1;
CREATE TEMPORARY TABLE auxTable1(

  avgValue float

);

DROP TABLE IF EXISTS auxTable2;
CREATE TEMPORARY TABLE auxTable2(

  avgValue float,
  constructorId int

);

INSERT INTO auxTable2 SELECT COALESCE(AVG(v.milisecondsStop), 1000000000) , t.constructorId FROM resultatsvolta AS v JOIN teams AS t ON v.driverId = t.driverId GROUP BY t.constructorId;

INSERT INTO auxTable1 SELECT avgValue FROM auxTable2;

SELECT t.nationalityDriver, AVG(r.miliseconds) AS temps
FROM teams AS t JOIN resultatscarrera AS r ON (t.driverId = r.driverId AND t.constructorId = r.constructorId) JOIN resultatsvolta AS v ON (v.driverId = r.driverId AND v.raceId = r.raceId)
GROUP BY t.driverId, t.constructorId
HAVING (SELECT COALESCE(a.avgValue, 1000000000) FROM auxTable2 AS a WHERE a.constructorId = t.constructorId) <= ALL(SELECT avgValue FROM auxTable1) AND NOT temps = 0;

SELECT DISTINCT t.forename, t.surname
FROM teams AS t JOIN resultatscarrera AS c ON c.driverId = t.driverId JOIN raceolap AS r ON r.raceId = c.raceId
WHERE c.q1 > c.q2 AND c.q2 > c.q3  AND c.fastestLapTime <= ALL(SELECT c1.q3 FROM resultatscarrera AS c1 JOIN raceolap AS r1 ON c1.raceId = r1.raceId WHERE r.raceId = r1.raceId AND c1.q1 IS NOT NULL AND c1.q2 IS NOT NULL AND c1.q3 IS NOT NULL) AND c.fastestLapTime <= ALL(SELECT c1.q2 FROM resultatscarrera AS c1 JOIN raceolap AS r1 ON c1.raceId = r1.raceId WHERE r.raceId = r1.raceId AND c1.q1 IS NOT NULL AND c1.q2 IS NOT NULL AND c1.q3 IS NOT NULL) AND c.fastestLapTime <= ALL(SELECT c1.q1 FROM resultatscarrera AS c1 JOIN raceolap AS r1 ON c1.raceId = r1.raceId WHERE r.raceId = r1.raceId AND c1.q1 IS NOT NULL AND c1.q2 IS NOT NULL AND c1.q3 IS NOT NULL) AND c.positionResultOrder <= 3 AND c.q1 IS NOT NULL AND c.q2 IS NOT NULL AND c.q3 IS NOT NULL AND c.fastestLapTime IS NOT NULL AND c.positionResultOrder IS NOT NULL;

SELECT DISTINCT t.forename, t.surname, c.fastestLapTime, c.fastestLapSpeed, r.nameCircuit
FROM teams AS t JOIN resultatscarrera AS c ON t.driverId = c.driverId JOIN raceolap AS r ON r.raceId = c.raceId JOIN resultatsvolta AS v ON (v.raceId = c.raceId AND v.driverId = c.driverId)
WHERE NOT c.fastestLapTime LIKE '%null%' AND NOT c.fastestLapSpeed LIKE '%null%' AND c.fastestLapTime IS NOT NULL AND c.fastestLapSpeed IS NOT NULL AND ((CONVERT(REPLACE(v.timeLap, ':', ''), DECIMAL(10, 6)) <= ALL(SELECT CONVERT(REPLACE(v1.timeLap, ':', ''), DECIMAL(10, 6)) FROM resultatsvolta AS v1 WHERE v1.raceId = v.raceId) AND c.fastestLapSpeed < ANY(SELECT c1.fastestLapSpeed FROM resultatscarrera AS c1 WHERE c1.raceId = c.raceId)))
UNION
SELECT DISTINCT t.forename, t.surname, c.fastestLapTime, c.fastestLapSpeed, r.nameCircuit
FROM teams AS t JOIN resultatscarrera AS c ON t.driverId = c.driverId JOIN raceolap AS r ON r.raceId = c.raceId JOIN resultatsvolta AS v ON (v.raceId = c.raceId AND v.driverId = c.driverId)
WHERE NOT c.fastestLapTime LIKE '%null%' AND NOT c.fastestLapSpeed LIKE '%null%' AND c.fastestLapTime IS NOT NULL AND c.fastestLapSpeed IS NOT NULL AND (CONVERT(REPLACE(v.timeLap, ':', ''), DECIMAL(10, 6)) > ANY(SELECT CONVERT(REPLACE(v1.timeLap, ':', ''), DECIMAL(10, 6)) FROM resultatsvolta AS v1 WHERE v1.raceId = v.raceId) AND c.fastestLapSpeed >= ALL(SELECT c1.fastestLapSpeed FROM resultatscarrera AS c1 WHERE c1.raceId = c.raceId));

SELECT DISTINCT t.forename, t.surname, r.nameCircuit, r.year, ABS(v1.position - v2.position) AS overtaking
FROM teams AS t JOIN resultatscarrera AS c ON t.driverId = c.driverId JOIN resultatsvolta AS v1 ON (v1.raceId = c.raceId AND v1.driverId = c.driverId) JOIN resultatsvolta AS v2 ON (v1.driverId = v2.driverId AND v1.raceId = v2.raceId AND NOT v1.lap = v2.lap) JOIN raceolap AS r ON (r.raceId = v1.raceId)
WHERE (v1.lap = v2.lap + 1 AND v1.position - v2.position <= ALL(SELECT v3.position - v4.position FROM resultatsvolta AS v3 JOIN resultatsvolta AS v4 ON (v3.driverId = v4.driverId AND v3.raceId = v4.raceId AND v3.lap = v4.lap + 1))) OR (v1.lap = c.laps AND v2.lap = 2 AND c.time IS NOT NULL AND v1.position - v2.position <= ALL(SELECT v3.position - v4.position FROM resultatsvolta AS v3 JOIN resultatsvolta AS v4 ON (v3.raceId = v4.raceId AND v3.driverId = v4.driverId AND NOT v3.lap = v4.lap) JOIN resultatscarrera AS c1 ON (c1.driverId = v3.driverId AND c1.raceId = v4.raceId) WHERE v3.lap = c1.laps AND v4.lap = 2 AND c.time IS NOT NULL));
