DROP DATABASE IF EXISTS F1OLTP;
CREATE DATABASE F1OLTP;
USE F1OLTP;

DROP TABLE IF EXISTS races;
CREATE TABLE races(

  raceId INT PRIMARY KEY,
  year INT,
  round INT,
  circuitId INT,
  name VARCHAR(255),
  date DATE,
  time VARCHAR(255),
  url VARCHAR(255) UNIQUE

);

DROP TABLE IF EXISTS seasons;
CREATE TABLE seasons(

  year INT PRIMARY KEY,
  url VARCHAR(255) UNIQUE

);

DROP TABLE IF EXISTS circuits;
CREATE TABLE circuits(

  circuitId INT PRIMARY KEY,
  circuitRef VARCHAR(255),
  name VARCHAR(255),
  location VARCHAR(255),
  country VARCHAR(255),
  lat float,
  lng float,
  alt INT,
  url VARCHAR(255) UNIQUE

);

DROP TABLE IF EXISTS constructorResults;
CREATE TABLE constructorResults(

  constructorResultsId INT PRIMARY KEY,
  raceId INT,
  constructorId INT,
  points INT,
  status VARCHAR(255)

);

DROP TABLE IF EXISTS constructorStandings;
CREATE TABLE constructorStandings(

  constructorStandingsId INT PRIMARY KEY,
  raceId INT,
  constructorId INT,
  points float,
  position INT,
  positionText VARCHAR(255),
  wins INT

);

DROP TABLE IF EXISTS constructors;
CREATE TABLE constructors(

  constructorId INT PRIMARY KEY,
  constructorRef VARCHAR(255),
  name VARCHAR(255) UNIQUE,
  nationality VARCHAR(255),
  url VARCHAR(255)

);


DROP TABLE IF EXISTS status;
CREATE TABLE status(

  statusId INT PRIMARY KEY,
  status VARCHAR(255)

);

DROP TABLE IF EXISTS driverStandings;
CREATE TABLE driverStandings(

  driverStandingsId INT PRIMARY KEY,
  raceId INT,
  driverId INT,
  points float,
  position INT,
  positionText VARCHAR(255),
  wins INT

);

DROP TABLE IF EXISTS drivers;
CREATE TABLE drivers(

  driverId INT PRIMARY KEY,
  driverRef VARCHAR(255),
  number INT,
  code VARCHAR(4),
  forename VARCHAR(255),
  surname VARCHAR(255),
  dob DATE,
  nationality VARCHAR(255),
  url VARCHAR(255) UNIQUE

);

DROP TABLE IF EXISTS lapTimes;
CREATE TABLE lapTimes(

  raceId INT,
  driverId INT,
  lap INT,
  position INT,
  time VARCHAR(255),
  miliseconds INT,
  PRIMARY KEY(raceId, driverId, lap)

);

DROP TABLE IF EXISTS pitStops;
CREATE TABLE pitStops(

  raceId INT,
  driverId INT,
  stop INT,
  lap INT,
  time time,
  duration VARCHAR(255),
  miliseconds INT,
  PRIMARY KEY(raceId, driverId, stop)

);

DROP TABLE IF EXISTS qualifying;
CREATE TABLE qualifying(

  qualifyId INT PRIMARY KEY,
  raceId INT,
  driverId INT,
  constructorId INT,
  number INT,
  position INT,
  q1 VARCHAR(255),
  q2 VARCHAR(255),
  q3 VARCHAR(255)

);

DROP TABLE IF EXISTS results;
CREATE TABLE results(

  resultId INT PRIMARY KEY,
  raceId INT,
  driverId INT,
  constructorId INT,
  number INT,
  grid INT,
  position INT,
  positionText VARCHAR(255),
  positionOrder INT,
  points float,
  laps INT,
  time VARCHAR(255),
  miliseconds INT,
  fastestLap INT,
  `rank` INT,
  fastestLapTime VARCHAR(255),
  fastestLapSpeed VARCHAR(255),
  statusId INT

);

DROP DATABASE IF EXISTS F1OLAP;
CREATE DATABASE F1OLAP;
USE F1OLAP;

DROP TABLE IF EXISTS F1OLAP.raceOLAP;
CREATE TABLE F1OLAP.raceOLAP(

  circuitId INT,
  year INT,
  raceId INT,
  circuitRef VARCHAR(255),
  nameCircuit VARCHAR(255),
  location VARCHAR(255),
  country VARCHAR(255),
  lat float,
  lng float,
  alt INT,
  urlCircuit VARCHAR(255),
  urlSeason VARCHAR(255),
  round INT,
  nameRace VARCHAR(255),
  date DATE,
  time VARCHAR(255),
  urlRace VARCHAR(255),
  PRIMARY KEY(raceId, year, circuitId)

);

DROP TABLE IF EXISTS F1OLAP.statusOLAP;
CREATE TABLE statusOLAP(

  statusId INT PRIMARY KEY,
  status VARCHAR(255)

);

DROP TABLE IF EXISTS F1OLAP.resultatsCarrera;
CREATE TABLE F1OLAP.resultatsCarrera(

  driverStandingsId INT,
  resultId INT,
  qualifyId INT,
  raceId INT,
  driverId INT,
  constructorId INT,
  constructorResultsId INT,
  constructorStandingId INT,
  pointsDriver INT,
  pointsResults INT,
  pointsConstructorStandings INT,
  pointsConstructorResults INT,
  positionDriver INT,
  positionDriverText VARCHAR(255),
  positionResult INT,
  positionResultText VARCHAR(255),
  positionResultOrder INT,
  positionConstructor INT,
  positionConstructorText VARCHAR(255),
  positionQualifying INT,
  winsConstructor INT,
  winsDriver INT,
  numberQualifying INT,
  numberResults INT,
  q1 VARCHAR(255),
  q2 VARCHAR(255),
  q3 VARCHAR(255),
  grid INT,
  laps INT,
  time VARCHAR(255),
  miliseconds INT,
  fastestLap INT,
  rankResults INT,
  fastestLapTime VARCHAR(255),
  fastestLapSpeed VARCHAR(255),
  status VARCHAR(255),
  statusId INT,
  PRIMARY KEY(resultId, qualifyId, driverStandingsId, constructorResultsId, constructorStandingId)

);

DROP TABLE IF EXISTS F1OLAP.resultatsVolta;
CREATE TABLE F1OLAP.resultatsVolta(

  raceId INT,
  driverId INT,
  lap INT,
  stop INT,
  position INT,
  timeLap VARCHAR(255),
  milisecondsLap INT,
  timeStop TIME,
  durationStop VARCHAR(255),
  milisecondsStop INT,
  PRIMARY KEY(raceId, driverId, lap, stop)

);

DROP TABLE IF EXISTS F1OLAP.teams;
CREATE TABLE F1OLAP.teams(

  constructorId INT,
  driverId INT,
  constructorRef VARCHAR(255),
  nameConstructor VARCHAR(255),
  nationalityConstructor VARCHAR(255),
  urlConstructor VARCHAR(255),
  driverRef VARCHAR(255),
  number INT,
  code VARCHAR(4),
  forename VARCHAR(255),
  surname VARCHAR(255),
  dob DATE,
  nationalityDriver VARCHAR(255),
  urlDriver VARCHAR(255),
  PRIMARY KEY(constructorId, driverId)

);
