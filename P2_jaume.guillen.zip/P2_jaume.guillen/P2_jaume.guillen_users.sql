DROP USER IF EXISTS analytic_user;
CREATE USER analytic_user;
GRANT CREATE VIEW ON f1olap.* TO analytic_user;
GRANT SELECT ON f1olap.* TO analytic_user;
GRANT SHOW VIEW ON f1olap.* TO analytic_user;

DROP USER IF EXISTS manager_user;
CREATE USER manager_user;
GRANT CREATE ON f1olap.* TO manager_user;
GRANT UPDATE ON f1olap.* TO manager_user;
GRANT INSERT ON f1olap.* TO manager_user;
GRANT DROP ON f1olap.* TO manager_user;
GRANT SELECT ON f1olap.* TO manager_user;
GRANT CREATE ON f1oltp.* TO manager_user;
GRANT UPDATE ON f1oltp.* TO manager_user;
GRANT INSERT ON f1oltp.* TO manager_user;
GRANT DROP ON f1oltp.* TO manager_user;
GRANT SELECT ON f1oltp.* TO manager_user;

DROP USER IF EXISTS rrhh_user;
CREATE USER rrhh_user;
GRANT CREATE USER ON *.* TO rrhh_user;