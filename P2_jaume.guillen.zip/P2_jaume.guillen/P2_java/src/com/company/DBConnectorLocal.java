package com.company;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnectorLocal {

    private static String userName;
    private static String password;
    private static String db;
    private static int port;
    private static String url;
    private static Connection conn;
    private static Statement s;
    private static DBConnectorLocal instance;

    /**
     * Constructor de DBConnectorLocal.
     * @param userName Usuari de la base de dades.
     * @param password Contrassenya de la base de dades.
     * @param db Nom de la base de dades.
     * @param port Port de la base de dades.
     */

    private DBConnectorLocal(String userName, String password, String db, int port, String url){

        this.userName = userName;
        this.password = password;
        this.db = db;
        this.port = port;
        this.url = url + ":" + port + "/" + db;
        instance = null;

    }

    /**
     * Obte una instancia de DBConnectorLocal.
     * @return La instancia de DBConnectorLocal.
     */

    public static DBConnectorLocal getInstance(){
        if(instance == null){
            instance = new DBConnectorLocal("root", "12345678", "F1OLTP", 3306, "jdbc:mysql://localhost");
            instance.connect();
        }
        return  instance;
    }

    /**
     * Connecta amb la base de dades.
     */

    public void connect() {
        try {
            Class.forName("com.mysql.jdbc.Connection");
            conn = (Connection) DriverManager.getConnection(url, userName, password);
            if (conn != null) {
                System.out.println("Connexió a base de dades "+url+" ... Ok");
            }
        }
        catch(SQLException ex) {
            System.out.println("Problema al connectar-nos a la BBDD --> "+url);
        }
        catch(ClassNotFoundException ex) {
            System.out.println(ex);
        }

    }

    /**
     * Envia a la base una query d'insercio.
     * @param query La query que volem enviar.
     */

    public void insertQuery(String query){
        try {
            s =(Statement) conn.createStatement();
            s.executeUpdate(query);

        } catch (SQLException ex) {
            System.out.println("Problema al Inserir --> " + ex.getSQLState());
        }
    }

    /**
     * Envia a la base una query de modificacio.
     * @param query La query que volem enviar.
     */

    public void updateQuery(String query){
        try {
            s =(Statement) conn.createStatement();
            s.executeUpdate(query);

        } catch (SQLException ex) {
            System.out.println("Problema al Modificar --> " + ex.getSQLState());
        }
    }

    /**
     * Envia a la base una query d'eliminacio.
     * @param query La query que volem enviar.
     */

    public void deleteQuery(String query){
        try {
            s =(Statement) conn.createStatement();
            s.executeUpdate(query);

        } catch (SQLException ex) {
            System.out.println("Problema al Eliminar --> " + ex.getSQLState());
        }

    }

    /**
     * Envia a la base una query de seleccio.
     * @param query La query que volem enviar.
     * @return El que ha seleccionat la query.
     */

    public ResultSet selectQuery(String query){
        ResultSet rs = null;
        try {
            s =(Statement) conn.createStatement();
            rs = s.executeQuery (query);

        } catch (SQLException ex) {
            System.out.println("Problema al Recuperar les dades --> " + ex.getSQLState());
        }
        return rs;
    }

    /**
     * Es desconnecta de la base de dades.
     */

    public void disconnect(){
        try {
            conn.close();
        } catch (SQLException e) {
            System.out.println("Problema al tancar la connexió --> " + e.getSQLState());
        }
    }

}