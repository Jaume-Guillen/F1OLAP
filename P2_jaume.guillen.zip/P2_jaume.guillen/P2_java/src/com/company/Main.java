package com.company;

import java.sql.ResultSet;

public class Main {

    public static void main(String[] args) {
        try {
            DBConnectorLocal c1 = DBConnectorLocal.getInstance();
            DBConnectorRemot c2 = DBConnectorRemot.getInstance();

            ResultSet rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM races;");

            while(rs.next()){

                System.out.println("INSERT INTO races VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", '" + rs.getString(5) + "', '" + rs.getDate(6) + "', '" + rs.getTime(7) + "', '" + rs.getString(8) + "');");

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO races VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", '" + rs.getString(5) + "', '" + rs.getDate(6) + "', '" + rs.getTime(7) + "', '" + rs.getString(8) + "');");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM seasons;");
            rs.beforeFirst();
            while(rs.next()){

                System.out.println("INSERT INTO seasons VALUES(" + rs.getInt(1) +  ", '" + rs.getString(2) + "');");

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO seasons VALUES(" + rs.getInt(1) +  ", '" + rs.getString(2) + "');");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM circuits;");
            rs.beforeFirst();
            while(rs.next()){

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO Circuits VALUES(" + rs.getInt(1) + ", '" + rs.getString(2) + "', '" + rs.getString(3) + "', '" + rs.getString(4) + "', '" + rs.getString(5) + "', " + rs.getFloat(6) + ", " + rs.getFloat(7) + ", " + rs.getInt(8) + ", '" + rs.getString(9) + "');");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM constructors;");
            rs.beforeFirst();

            while(rs.next()){

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO constructors VALUES(" + rs.getInt(1) + ", '" + rs.getString(2) + "', '" + rs.getString(3) + "', '" + rs.getString(4) + "', '" + rs.getString(5) + "');");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM drivers;");
            rs.beforeFirst();

            while(rs.next()){

                System.out.println("INSERT INTO drivers VALUES(" + rs.getInt(1) + ", \"" + rs.getString(2) + "\", " + rs.getInt(3) + ", \"" + rs.getString(4) + "\", '" + rs.getString(5) + "', '" + rs.getString(6) + "', '" + rs.getDate(7) + "', '" + rs.getString(8) + "', '" + rs.getString(9) + "');");

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO drivers VALUES(" + rs.getInt(1) + ", \"" + rs.getString(2) + "\", " + rs.getInt(3) + ", \"" + rs.getString(4) + "\", \"" + rs.getString(5) + "\", \"" + rs.getString(6) + "\", '" + rs.getDate(7) + "', '" + rs.getString(8) + "', '" + rs.getString(9) + "');");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM lapTimes;");
            rs.beforeFirst();

            while(rs.next()){

                System.out.println("INSERT INTO lapTimes VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", '" + rs.getString(5) + "', " + rs.getInt(6) + ");");

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO lapTimes VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", '" + rs.getString(5) + "', " + rs.getInt(6) + ");");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM pitStops;");
            rs.beforeFirst();

            while(rs.next()){

                System.out.println("INSERT INTO pitStops VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", '" + rs.getTime(5) + "', '" + rs.getString(6) + "', " + rs.getInt(7) + ");");

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO pitStops VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", '" + rs.getTime(5) + "', '" + rs.getString(6) + "', " + rs.getInt(7) + ");");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM driverStandings;");
            rs.beforeFirst();

            while(rs.next()){

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO driverStandings VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getFloat(4) + ", " + rs.getInt(5) + ", '" + rs.getString(6) + "', " + rs.getInt(7) + ");");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM results;");
            rs.beforeFirst();

            while(rs.next()){

                System.out.println("INSERT INTO results VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", " + rs.getInt(5) + ", " + rs.getInt(6) + ", " + rs.getInt(7) + ", '" + rs.getString(8) + "', " + rs.getInt(9) + ", " + rs.getFloat(10) + ", " + rs.getInt(11) + ", '" + rs.getString(12) + "', " + rs.getInt(13) + ", " + rs.getInt(14) + ", " + rs.getInt(15) + ", '" + rs.getString(16) + "', '" + rs.getString(17) + "', " + rs.getInt(18) + ");");

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO results VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", " + rs.getInt(5) + ", " + rs.getInt(6) + ", " + rs.getInt(7) + ", '" + rs.getString(8) + "', " + rs.getInt(9) + ", " + rs.getFloat(10) + ", " + rs.getInt(11) + ", '" + rs.getString(12) + "', " + rs.getInt(13) + ", " + rs.getInt(14) + ", " + rs.getInt(15) + ", '" + rs.getString(16) + "', '" + rs.getString(17) + "', " + rs.getInt(18) + ");");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM qualifying;");
            rs.beforeFirst();

            while(rs.next()){

                System.out.println("INSERT INTO qualifying VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", " + rs.getInt(5) + ", " + rs.getInt(6) + ", '" + rs.getString(7) + "', '" + rs.getString(8) + "', '" + rs.getString(9) + "');");

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO qualifying VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getInt(4) + ", " + rs.getInt(5) + ", " + rs.getInt(6) + ", '" + rs.getString(7) + "', '" + rs.getString(8) + "', '" + rs.getString(9) + "');");

            }
            rs.close();


            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM constructorStandings;");
            rs.beforeFirst();

            while(rs.next()){

                System.out.println("INSERT INTO constructorStandings VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getFloat(4) + ", " + rs.getInt(5) + ", '" + rs.getString(6) + "', " + rs.getInt(7) + ");");
                DBConnectorLocal.getInstance().insertQuery("INSERT INTO constructorStandings VALUES(" + rs.getInt(1) + ", " + rs.getInt(2) + ", " + rs.getInt(3) + ", " + rs.getFloat(4) + ", " + rs.getInt(5) + ", '" + rs.getString(6) + "', " + rs.getInt(7) + ");");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM constructorResults;");
            rs.beforeFirst();
            while(rs.next()){

                System.out.println("INSERT INTO constructorResults VALUES(" + rs.getInt(1) + ", " +  rs.getInt(2) + ", "  +  rs.getInt(3) + ", " +  rs.getFloat(4) + ", '" + rs.getString(5) + "');");
                DBConnectorLocal.getInstance().insertQuery("INSERT INTO constructorResults VALUES(" + rs.getInt(1) + ", " +  rs.getInt(2) + ", "  +  rs.getInt(3) + ", " +  rs.getFloat(4) + ", '" + rs.getString(5) + "');");

            }
            rs.close();

            rs = DBConnectorRemot.getInstance().selectQuery("SELECT * FROM status;");
            rs.beforeFirst();

            while(rs.next()){

                System.out.println("INSERT INTO status VALUES(" + rs.getInt(1) +  ", '" + rs.getString(2) + "');");

                DBConnectorLocal.getInstance().insertQuery("INSERT INTO status VALUES(" + rs.getInt(1) +  ", '" + rs.getString(2) + "');");

            }
            rs.close();

            c1.disconnect();
            c2.disconnect();
        }catch(Exception e){

            e.printStackTrace();

        }


    }
}

