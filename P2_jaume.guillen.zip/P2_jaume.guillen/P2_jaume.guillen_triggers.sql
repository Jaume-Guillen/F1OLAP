USE F1OLTP;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_races_in $$
CREATE TRIGGER tr_races_in AFTER INSERT
  ON f1oltp.races
  FOR EACH ROW BEGIN
  INSERT INTO f1olap.raceolap(raceId, circuitId, year, round, nameRace, date, time, urlRace) VALUES(NEW.raceId, NEW.circuitId, NEW.year, NEW.round, NEW.name, NEW.date, NEW.time, NEW.url);
end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_seasons_in $$
CREATE TRIGGER tr_seasons_in AFTER INSERT
  ON f1oltp.seasons
  FOR EACH ROW BEGIN
  UPDATE f1olap.raceolap SET urlSeason = NEW.url WHERE year = NEW.year;
end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_circuits_in $$
CREATE TRIGGER tr_circuits_in AFTER INSERT
  ON f1oltp.circuits
  FOR EACH ROW BEGIN
  UPDATE f1olap.raceolap SET circuitRef = NEW.circuitRef, nameCircuit = NEW.name, location = NEW.location, country = NEW.country, lat = NEW.lat, lng = NEW.lng, alt = NEW.alt, urlCircuit = NEW.url WHERE circuitId = NEW.circuitId;
end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_lapTimes_in $$
CREATE TRIGGER tr_lapTimes_in AFTER INSERT
  ON f1oltp.lapTimes
  FOR EACH ROW BEGIN
  INSERT INTO f1olap.resultatsvolta(raceId, driverId, lap, position, timeLap, milisecondsLap, stop) VALUES(NEW.raceId, NEW.driverId, NEW.lap, NEW.position, NEW.time, NEW.miliseconds, -1);
end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_stops_in $$
CREATE TRIGGER tr_stops_in AFTER INSERT
  ON f1oltp.pitStops
  FOR EACH ROW BEGIN
  UPDATE f1olap.resultatsvolta SET stop = NEW.stop, timeStop = NEW.time, durationStop = NEW.duration, milisecondsStop = NEW.miliseconds WHERE raceId = NEW.raceId AND driverId = NEW.driverId AND lap = NEW.lap;
end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_driverStandings_in $$
CREATE TRIGGER tr_driverStandings_in AFTER INSERT
  ON f1oltp.driverStandings
  FOR EACH ROW BEGIN
  INSERT INTO f1olap.resultatscarrera(driverStandingsId, raceId, driverId, pointsDriver, positionDriver, positionDriverText, winsDriver, constructorResultsId, constructorStandingId, qualifyId, resultId) VALUES(NEW.driverStandingsId, NEW.raceId, NEW.driverId, NEW.points, NEW.position, NEW.positionText, NEW.wins, -1, -1, -1, -1);
end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_results_in $$
CREATE TRIGGER tr_results_in AFTER INSERT
  ON f1oltp.results
  FOR EACH ROW BEGIN
  UPDATE f1olap.resultatscarrera SET resultId = NEW.resultId, positionResultText = NEW.positionText, positionResultOrder = NEW.positionOrder, pointsResults = NEW.points, laps = NEW.laps, time = NEW.time, miliseconds = NEW.miliseconds, fastestLap = NEW.fastestLap, rankResults = NEW.`rank`, fastestLapTime = NEW.fastestLapTime, fastestLapSpeed = NEW.fastestLapSpeed, statusId = NEW.statusId, grid = NEW.grid, constructorId = NEW.constructorId, numberResults = NEW.number WHERE raceId = NEW.raceId AND driverId = NEW.driverId;

  IF(NOT NEW.resultId IN (SELECT resultId FROM f1olap.resultatscarrera)) THEN

    INSERT INTO f1olap.resultatscarrera(raceId, driverId, qualifyId, resultId, positionResultText, positionResultOrder, pointsResults, laps, time, miliseconds, fastestLap, rankResults, fastestLapTime, fastestLapSpeed, statusId, grid, driverStandingsId, constructorResultsId, constructorStandingId) SELECT NEW.raceId, NEW.driverId, 1, NEW.resultId, NEW.positionText, NEW.positionOrder, NEW.points, NEW.laps, NEW.time, NEW.miliseconds, NEW.fastestLap, NEW.`rank`, NEW.fastestLapTime, NEW.fastestLapSpeed, NEW.statusId, NEW.grid, -1, -1, -1;

  END IF;

  IF (NEW.driverId NOT IN (SELECT driverId FROM f1olap.teams WHERE teams.constructorId = NEW.constructorId)) THEN

    INSERT INTO f1olap.teams
    SELECT c.constructorId, d.driverId, c.constructorRef, c.name, c.nationality, c.url, d.driverRef, d.number, d.code, d.forename, d.surname, d.dob, d.nationality, d.url
    FROM f1oltp.drivers AS d, f1oltp.constructors AS c
    WHERE d.driverId = NEW.driverId AND c.constructorId = NEW.constructorId;

  END IF;

end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_qualifying_in $$
CREATE TRIGGER tr_qualifying_in AFTER INSERT
  ON f1oltp.qualifying
  FOR EACH ROW BEGIN
  UPDATE f1olap.resultatscarrera SET qualifyId = NEW.qualifyId, constructorId = NEW.constructorId, numberQualifying = NEW.number, positionQualifying = NEW.position, q1 = NEW.q1, q2 = NEW.q2, q3 = NEW.q3 WHERE raceId = NEW.raceId AND driverId = NEW.driverId;
end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_constrStanding_in $$
CREATE TRIGGER tr_constrStanding_in AFTER INSERT
  ON f1oltp.constructorStandings
  FOR EACH ROW BEGIN
  UPDATE f1olap.resultatscarrera SET constructorStandingId = NEW.constructorStandingsId, pointsConstructorStandings = NEW.points, positionConstructor = NEW.position, positionConstructorText = NEW.positionText, winsConstructor = NEW.wins WHERE raceId = NEW.raceId AND constructorId = NEW.constructorId;
end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_constrResults_in $$
CREATE TRIGGER tr_constrResults_in AFTER INSERT
  ON f1oltp.constructorResults
  FOR EACH ROW BEGIN
  UPDATE f1olap.resultatscarrera SET status = NEW.status, constructorResultsId = NEW.constructorResultsId, pointsConstructorResults = NEW.points WHERE raceId = NEW.raceId AND constructorId = NEW.constructorId;
end $$
DELIMITER ;

DELIMITER $$
DROP TRIGGER IF EXISTS tr_status_in $$
CREATE TRIGGER tr_status_in AFTER INSERT
  ON f1oltp.status
  FOR EACH ROW BEGIN
  INSERT INTO f1olap.statusolap(statusId, status) VALUES(NEW.statusId, NEW.status);
end $$
DELIMITER ;

DROP DATABASE IF EXISTS F1_comprovacio;
CREATE DATABASE F1_comprovacio;
USE F1_comprovacio;

SET @@global.event_scheduler = 1;

DELIMITER $$
DROP EVENT IF EXISTS comprova_taules$$
CREATE EVENT IF NOT EXISTS comprova_taules
ON SCHEDULE EVERY 1 DAY
COMMENT 'EVENT per tal de comprovar si la importacio ha sigut exitosa.'
DO CALL F1_comprovacio.comprovacio_imp();
DELIMITER ;